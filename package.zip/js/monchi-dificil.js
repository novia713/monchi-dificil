

window.addEventListener('DOMContentLoaded', function() {
  /*
  var script = document.createElement('script');
  script.src = "twemoji/twemoji.min.js";
  document.body.appendChild(script);
  console.log(script);
  */

  console.log("monchi addon 2 started");
  var theme = document.getElementById('theme');
  theme.content="orange";


  /* DIFICULTAD */
  document.getElementById("difficulty_container").style.display = "block";


  /* END DIFICULTAD */


/*
    btn_1.innerHTML = "✊"; //🚹
    btn_1.setAttribute("val","✊"); //♣
    btn_2.innerHTML = "🚹";
    btn_3.innerHTML = "♠"; //✋
    btn_4.innerHTML = "㊗"; //㊙
*/
});



