

window.addEventListener('DOMContentLoaded', function() {

  console.log("monchi addon dificil started");
  var theme = document.getElementById('theme');
  theme.content="orange";


  /* DIFICULTAD */

  document.getElementById("difficulty_container").style.display = "block";

  /* END DIFICULTAD */
});



/**
 *   var script = document.createElement('script');
  script.src = "twemoji/twemoji.min.js";
  document.body.appendChild(script);
  console.log(script);
    btn_1.innerHTML = "✊"; //🚹
    btn_1.setAttribute("val","✊"); //♣
    btn_2.innerHTML = "🚹";
    btn_3.innerHTML = "♠"; //✋
    btn_4.innerHTML = "㊗"; //㊙
*/
